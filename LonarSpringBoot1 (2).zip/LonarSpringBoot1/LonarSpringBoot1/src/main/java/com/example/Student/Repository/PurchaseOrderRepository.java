package com.example.Student.Repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@Repository
public class PurchaseOrderRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Fetch purchase order header data
    public Map<String, Object> getPurchaseOrderHeader(Long po_Header_Id) {
        String query = "SELECT poh.po_number,poh.revision_num,poh.po_date,poh.revision_date\n" +
                "      ,vcm.company_name,vcm.logo_path\n" +
                "      ,mb.branch_name,mb.gst_reg_no as company_gst\n" +
                "      ,mv.vendor_name,mva.address_code\n" +
                "      ,concat(mva.address1,', ',mva.address2,', ',mva.address3,', ',mva.city,'-',mva.pin_code) as vendor_address\n" +
                "      ,mva.gst_reg_no as vendor_gst\n" +
                "      ,mvc.contact_person,mvc.contact_mobile,mvc.contact_email\n" +
                "      ,mpt.term_name as payment_term\n" +
                "      ,poh.currency_code\n" +
                "      ,concat(me.first_name,' ',me.last_name) as buyer,me.official_email as buyer_email\n" +
                "FROM lt_po_headers poh\n" +
                "    ,lt_mast_vendors mv\n" +
                "    ,lt_mast_vendor_addresses mva\n" +
                "    ,lt_mast_vendor_contacts mvc\n" +
                "    ,lt_mast_branches mb\n" +
                "    ,lt_vend_company_master vcm\n" +
                "    ,lt_mast_payment_terms mpt\n" +
                "    ,lt_mast_employees me\n" +
                "WHERE poh.vendor_id = mv.vendor_id\n" +
                "AND   poh.vendor_add_id = mva.vendor_add_id\n" +
                "AND   poh.vendor_contact_id = mvc.vendor_contact_id\n" +
                "AND   poh.billing_add_id = mb.branch_id\n" +
                "AND   poh.company_id = vcm.company_id\n" +
                "AND   poh.terms_id = mpt.payterm_id\n" +
                "AND   poh.buyer_id = me.employee_id\n" +
                "AND   poh.po_header_id = ?";
        return jdbcTemplate.queryForMap(query, po_Header_Id);
    }

    // Fetch purchase order lines
    public List<Map<String, Object>> getPurchaseOrderLines(Long po_Header_Id) {
        String query = "SELECT pol.line_num,pol.line_type\n" +
                "      ,pol.product_code,mp.product_name\n" +
                "      ,pol.quantity,pol.unit_price,mcmv.value_name as UOM\n" +
                "      ,pol.line_amount\n" +
                "      ,pol.tax_amount \n" +
                "      ,pol.total_amount\n" +
                "      ,mp.product_desc\n" +
                "      ,pol.note_to_vendor\n" +
                "FROM lt_po_lines pol\n" +
                "    ,lt_mast_products mp\n" +
                "    ,lt_mast_comn_master mcm\n" +
                "    ,lt_mast_comn_master_values mcmv\n" +
                "WHERE pol.product_id = mp.product_id\n" +
                "AND   mcmv.value_code = mp.uom\n" +
                "AND   mcm.master_id = mcmv.master_id\n" +
                "AND   mcm.master_name = 'UOM_MASTER'\n" +
                "AND   pol.po_header_id = ?";
        return jdbcTemplate.queryForList(query, po_Header_Id);
    }
    public List<Map<String, Object>> getPurchaseOrderTaxes(Long po_Header_Id) {
        String query = "SELECT pol.line_num,mp.hsn_sac_code\n" +
                "\t  ,mtm.tax_name\n" +
                "      ,pol.line_amount,mtm.tax_rate\n" +
                "      ,plt.tax_amount\n" +
                "FROM lt_po_line_taxes plt\n" +
                "    ,lt_mast_tax_master mtm\n" +
                "    ,lt_po_lines pol\n" +
                "    ,lt_mast_products mp\n" +
                "WHERE plt.tax_id = mtm.tax_id\n" +
                "AND   pol.po_line_id = plt.po_line_id\n" +
                "AND   pol.product_id = mp.product_id\n" +
                "AND   plt.po_header_id = ?";
        return jdbcTemplate.queryForList(query, po_Header_Id);
    }

    public String loadHtmlTemplate(String filePath) {
        try {
            Path path = new ClassPathResource(filePath).getFile().toPath();
            return Files.readString(path);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load HTML template: " + filePath, e);
        }
    }


}
