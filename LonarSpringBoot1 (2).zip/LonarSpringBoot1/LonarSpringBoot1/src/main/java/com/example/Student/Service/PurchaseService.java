package com.example.Student.Service;

import com.example.Student.Repository.PurchaseOrderRepository;
import com.example.Student.Service.PurchaseCalculationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

@Service
public class PurchaseService {

    @Autowired
    private PurchaseOrderRepository repository;

    @Autowired
    private PurchaseCalculationService calculationService;

    private BigDecimal totalAmount = BigDecimal.ZERO;

    public String generateHtml(Long po_Header_Id) {
        // Fetch data from the database with null checks
        Map<String, Object> header = repository.getPurchaseOrderHeader(po_Header_Id);
        if (header == null) {
            throw new RuntimeException("Purchase order header not found for ID: " + po_Header_Id);
        }

        List<Map<String, Object>> lines = repository.getPurchaseOrderLines(po_Header_Id);
        if (lines == null) {
            throw new RuntimeException("Purchase order lines not found for ID: " + po_Header_Id);
        }

        List<Map<String, Object>> taxes = repository.getPurchaseOrderTaxes(po_Header_Id);
        if (taxes == null) {
            taxes = List.of(); // Use an empty list if taxes are not available
        }

        String template = repository.loadHtmlTemplate("templates/index.html");
        if (template == null || template.isEmpty()) {
            throw new RuntimeException("HTML template not found.");
        }

        // Replace placeholders in the template with header data
        template = replacePlaceholders(template, header);

        // Generate the line items table rows
        StringBuilder linesHtml = new StringBuilder();
        for (Map<String, Object> line : lines) {
            linesHtml.append("<tr>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("line_num", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("line_type", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("product_code", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("product_name", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("quantity", ""))).append("</td>")
                    .append("<td>").append(formatNumber(line.getOrDefault("unit_price", 0))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("UOM", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("product_desc", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(line.getOrDefault("note_to_vendor", ""))).append("</td>")
                   // .append("<td>").append(formatNumber(line.getOrDefault("line_amount", 0))).append("</td>")
                   // .append("<td>").append(formatNumber(line.getOrDefault("tax_amount", 0))).append("</td>")
                    .append("<td>").append(formatNumber(line.getOrDefault("total_amount", 0))).append("</td>")
                    .append("</tr>");
        }

        // Generate the tax details table rows
        StringBuilder taxesHtml = new StringBuilder();
        for (Map<String, Object> tax : taxes) {
            taxesHtml.append("<tr>")
                    .append("<td>").append(escapeHtml(tax.getOrDefault("line_num", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(tax.getOrDefault("hsn_sac_code", ""))).append("</td>")
                    .append("<td>").append(escapeHtml(tax.getOrDefault("tax_name", ""))).append("</td>")
                    .append("<td>").append(formatNumber(tax.getOrDefault("line_amount", 0))).append("</td>")
                    .append("<td>").append(formatNumber(tax.getOrDefault("tax_rate", 0))).append("</td>")
                    .append("<td>").append(formatNumber(tax.getOrDefault("tax_amount", 0))).append("</td>")
                    .append("</tr>");
        }

        // Replace table body placeholders
        template = template.replace("{{table_body}}", linesHtml.toString());
        template = template.replace("{{tax_table}}", taxesHtml.toString());

        // Calculate and replace total values
        totalAmount = getTotalAmount(lines);
        Map<String, String> calculatedValues = calculationService.calculateTotals(totalAmount);

        template = template.replace("{{total_amount}}", calculatedValues.getOrDefault("total_amount", "0.00"));
        template = template.replace("{{levies}}", calculatedValues.getOrDefault("levies", "0.00"));
        template = template.replace("{{grand_total}}", calculatedValues.getOrDefault("grand_total", "0.00"));
        template = template.replace("{{amount_in_words}}", calculatedValues.getOrDefault("amount_in_words", ""));
        template = template.replace("{{tax_amount_in_words}}", calculatedValues.getOrDefault("tax_amount_in_words", ""));
        String remarks = header.getOrDefault("remarks", "No remarks provided").toString();
        template = template.replace("{{remarks}}", escapeHtml(remarks));
        return template;
    }

    private BigDecimal getTotalAmount(List<Map<String, Object>> lines) {
        BigDecimal total = BigDecimal.ZERO;
        for (Map<String, Object> line : lines) {
            Object lineAmount = line.get("total_amount");
            if (lineAmount != null) {
                try {
                    total = total.add(new BigDecimal(lineAmount.toString()));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return total;
    }

    private String replacePlaceholders(String template, Map<String, Object> data) {
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String placeholder = "{{" + entry.getKey() + "}}";
            String value = entry.getValue() != null ? entry.getValue().toString() : "";
            template = template.replace(placeholder, HtmlUtils.htmlEscape(value));
        }
        return template;
    }

    private String escapeHtml(Object value) {
        return value == null ? "" : HtmlUtils.htmlEscape(value.toString());
    }

    private String formatNumber(Object value) {
        if (value == null) return "0.00";
        try {
            DecimalFormat df = new DecimalFormat("#,##0.00");
            return df.format(new BigDecimal(value.toString()));
        } catch (NumberFormatException e) {
            return "0.00";
        }
    }
}
