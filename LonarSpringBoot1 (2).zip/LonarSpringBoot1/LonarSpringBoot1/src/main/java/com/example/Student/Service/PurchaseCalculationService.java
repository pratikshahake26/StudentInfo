package com.example.Student.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class PurchaseCalculationService {

    public Map<String, String> calculateTotals(BigDecimal totalAmount) {
        // Constants for levies
        final BigDecimal LEVY_RATE = new BigDecimal("0.09");

        // Calculate levies
        BigDecimal levies = totalAmount.multiply(LEVY_RATE);

        // Calculate grand total
        BigDecimal grandTotal = totalAmount.add(levies);

        // Format numbers
        DecimalFormat df = new DecimalFormat("#,##0.00");
        String formattedTotalAmount = df.format(totalAmount);
        String formattedLevies = df.format(levies);
        String formattedGrandTotal = df.format(grandTotal);

        // Convert amounts to words
        String amountInWords = convertToWords(totalAmount);
        String taxAmountInWords = convertToWords(levies);

        // Create a map to store the calculated values
        Map<String, String> calculatedValues = new HashMap<>();
        calculatedValues.put("total_amount", formattedTotalAmount);
        calculatedValues.put("levies", formattedLevies);
        calculatedValues.put("grand_total", formattedGrandTotal);
        calculatedValues.put("amount_in_words", amountInWords);
        calculatedValues.put("tax_amount_in_words", taxAmountInWords);

        return calculatedValues;
    }

    private String convertToWords(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) == 0) {
            return "Zero Only";
        }

        String formattedAmount = new DecimalFormat("#.00").format(amount);
        String[] parts = formattedAmount.split("\\.");
        long integerPart = Long.parseLong(parts[0]);
        int decimalPart = Integer.parseInt(parts[1]);

        StringBuilder words = new StringBuilder();
        words.append(convertNumberToWords(integerPart)).append(" Rupees");

        if (decimalPart > 0) {
            words.append(" and ").append(convertNumberToWords(decimalPart)).append(" Paise");
        }

        words.append(" Only");
        return words.toString();
    }

    private String convertNumberToWords(long number) {
        final String[] UNITS = {
                "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
        };

        final String[] TENS = {
                "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
        };

        final String[] SCALES = {
                "", "Thousand", "Million", "Billion", "Trillion"
        };

        if (number == 0) {
            return "";
        }

        StringBuilder words = new StringBuilder();

        int scaleIndex = 0;
        while (number > 0) {
            int chunk = (int) (number % 1000);
            if (chunk > 0) {
                String chunkInWords = convertChunkToWords(chunk);
                if (scaleIndex > 0) {
                    chunkInWords += " " + SCALES[scaleIndex];
                }
                words.insert(0, chunkInWords + " ");
            }
            number /= 1000;
            scaleIndex++;
        }

        return words.toString().trim();
    }

    private String convertChunkToWords(int number) {
        final String[] UNITS = {
                "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
        };

        final String[] TENS = {
                "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"
        };

        StringBuilder chunkWords = new StringBuilder();

        if (number >= 100) {
            chunkWords.append(UNITS[number / 100]).append(" Hundred ");
            number %= 100;
        }

        if (number >= 20) {
            chunkWords.append(TENS[number / 10]).append(" ");
            number %= 10;
        }

        if (number > 0) {
            chunkWords.append(UNITS[number]).append(" ");
        }

        return chunkWords.toString().trim();
    }
}
