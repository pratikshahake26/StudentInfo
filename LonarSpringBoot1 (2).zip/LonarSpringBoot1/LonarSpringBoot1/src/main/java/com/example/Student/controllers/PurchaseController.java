package com.example.Student.controllers;

import com.example.Student.Service.PurchaseService;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;

import javax.servlet.http.HttpServletResponse;
import java.io.StringReader;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/po")
public class PurchaseController {

    @Autowired
    private PurchaseService service;

    @GetMapping("/generatePdf/{po_header_id}")
    public void generatePdf(@PathVariable long po_header_id, HttpServletResponse response) {
        try {
            // Generate HTML content

            String htmlContent = service.generateHtml(po_header_id );

            // Ensure the HTML is well-formed
            htmlContent = ensureWellFormedHtml(htmlContent);

            // Set the response type and header for the PDF file
            response.setContentType("application/pdf");
            response.setHeader("Content-Disposition", "attachment; filename=PurchaseOrder_" + po_header_id + ".pdf");

            // Create a PDF document from the HTML content
            Document document = new Document();
            PdfWriter writer = PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            // Convert HTML to PDF using XMLWorkerHelper
            XMLWorkerHelper.getInstance().parseXHtml(writer, document, new StringReader(htmlContent));

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Ensures the provided HTML content is well-formed for XMLWorkerHelper.
     *
     * @param htmlContent the original HTML content
     * @return well-formed HTML content
     */
    private String ensureWellFormedHtml(String htmlContent) {
        // Add basic HTML structure if missing
        if (!htmlContent.startsWith("<!DOCTYPE")) {
            htmlContent = "<!DOCTYPE html>" +
                    "<html>" +
                    "<head><meta charset='UTF-8'></head>" +
                    "<body>" + htmlContent + "</body>" +
                    "</html>";
        }
        return htmlContent;
    }
}
